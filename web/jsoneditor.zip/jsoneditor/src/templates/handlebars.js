JSONEditor.defaults.templates.handlebars = function() {
  return window.Handlebars;
};
